
<?php
    include 'connection.php';
    $cn = $_POST['car_name'];
    $cm = $_POST['car_model'];
    $mb = $_POST['man_name'];
    $price = $_POST['price'];
    $uploaddir = 'uploads/';
    $image = $uploaddir . basename($_FILES['image']['name']);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $image)) {
        echo "Image succesfully uploaded.";
    } else {
        echo "Image uploading failed.";
    }
    $sql = "INSERT INTO `cars_model`( `car_name`,`car_model`,`man_by`,`price`,`image`) VALUES ('$cn','$cm','$mb','$price','$image')";
    if($conn->query($sql)==True){
      header('location:cars_records.php');
      $success = 'Car Successfully Add.';
    }
    else{
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
?>
